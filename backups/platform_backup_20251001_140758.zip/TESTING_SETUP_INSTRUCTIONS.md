# 🚀 Algorithmic Trading Platform - Testing Setup Instructions

This document provides complete instructions for setting up and running the platform for testing, including all Phase G order flow validation.

## 📋 Prerequisites

### Required Software
- **Python 3.11+** with pip
- **Node.js** (for K6 performance testing)
- **K6** performance testing tool
- **Git** version control
- **PowerShell** (Windows) or Bash (Linux/Mac)

### Environment Setup
- **Virtual Environment**: Python venv activated
- **API Keys**: Alpaca Paper Trading credentials
- **Database**: SQLite (automatic) or PostgreSQL (optional)

## 🔧 Initial Setup

### 1. Clone and Navigate to Repository
```powershell
git clone <repository-url>
cd algotrading_platform
```

### 2. Create and Activate Virtual Environment
```powershell
# Create virtual environment
python -m venv venv

# Activate virtual environment (Windows PowerShell)
.\venv\Scripts\Activate.ps1

# Verify activation (should show venv path)
where python
```

### 3. Install Dependencies
```powershell
# Install Python dependencies
pip install -r requirements.txt

# Verify critical packages
pip show fastapi uvicorn sqlalchemy pydantic
```

### 4. Install K6 for Performance Testing
```powershell
# Windows (using chocolatey)
choco install k6

# Or download from: https://k6.io/docs/getting-started/installation/

# Verify installation
k6 version
```

## 🔑 Environment Configuration

### 1. Set Up Alpaca Paper Trading Credentials
```powershell
# Set environment variables (required for real broker integration)
$env:ALPACA_API_KEY_ID="PK6HHOLVI6KJ2DTESPKR"
$env:ALPACA_API_SECRET_KEY="vpuCh1GHrr6NBjIecJdc8dGQRa0f302vSmD8kM7W"
$env:ALPACA_PAPER="true"
$env:USE_MOCK_BROKER="false"
```

### 2. Verify Alpaca Credentials (Optional)
```powershell
# Test API connectivity
python -c "
import os; import httpx
api_key = os.getenv('ALPACA_API_KEY_ID')
api_secret = os.getenv('ALPACA_API_SECRET_KEY')
headers = {'APCA-API-KEY-ID': api_key, 'APCA-API-SECRET-KEY': api_secret}
response = httpx.get('https://paper-api.alpaca.markets/v2/account', headers=headers)
print('✅ Valid credentials' if response.status_code == 200 else f'❌ Auth failed: {response.text[:200]}')
"
```

## 🚀 Starting the Platform

### 1. Full Server Startup Command
```powershell
# Navigate to project directory
cd "c:\Users\Marsel\intra\algotrading_platform"

# Activate virtual environment
.\venv\Scripts\Activate.ps1

# Set environment variables and start server
$env:ALPACA_API_KEY_ID="PK6HHOLVI6KJ2DTESPKR"
$env:ALPACA_API_SECRET_KEY="vpuCh1GHrr6NBjIecJdc8dGQRa0f302vSmD8kM7W"
$env:ALPACA_PAPER="true"
$env:USE_MOCK_BROKER="false"
python -m uvicorn backend.api.main:app --host 0.0.0.0 --port 8000 --reload
```

### 2. Verify Server Startup
The server should show:
```
INFO:     Started server process [xxxxx]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000
```

### 3. Test Server Health
Open browser or use curl:
```powershell
# Test health endpoint
curl http://localhost:8000/

# Test API documentation
# Browser: http://localhost:8000/docs
```

## 🧪 Running Tests

### 1. Basic API Test
```powershell
# Test authentication
python -c "
import requests
login_data = {'username': 'admin', 'password': 'admin123'}
response = requests.post('http://localhost:8000/api/v1/auth/login', json=login_data)
print('✅ Auth working' if response.status_code == 200 else f'❌ Auth failed: {response.status_code}')
"
```

### 2. Order Flow Test (Manual)
```powershell
# Test order creation with multiple symbols
python -c "
import requests
import json

# Login
login_data = {'username': 'admin', 'password': 'admin123'}
login_resp = requests.post('http://localhost:8000/api/v1/auth/login', json=login_data)
token = login_resp.json()['access_token']
headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}

# Test different symbols (some will create orders, some will hold)
symbols = ['AAPL', 'TSLA', 'NVDA', 'GOOGL', 'MSFT']
for symbol in symbols:
    act_data = {'symbol': symbol, 'lookback': 200, 'size_mode': 'fixed', 'fixed_qty': 10.0}
    act_resp = requests.post('http://localhost:8000/api/v1/signals/act', json=act_data, headers=headers)
    
    if act_resp.status_code == 200:
        data = act_resp.json()
        action = data['action']
        reason = data['signal']['reason']
        order_id = data['order']['order_id'] if data['order'] else 'None'
        print(f'{symbol}: {action} - Order ID: {order_id}')
        print(f'   Reason: {reason}')
    else:
        print(f'{symbol}: ERROR - {act_resp.status_code}')
"
```

### 3. K6 Performance Tests

#### Quick Test (5 seconds, 1 user)
```powershell
k6 run --duration 5s --vus 1 -e USERNAME=admin -e PASSWORD=admin123 perf/k6_order_flow.js
```

#### Standard Test (30 seconds, 2 users)
```powershell
k6 run --duration 30s --vus 2 -e USERNAME=admin -e PASSWORD=admin123 perf/k6_order_flow.js
```

#### Comprehensive Test (60 seconds, 3 users)
```powershell
k6 run --duration 60s --vus 3 -e USERNAME=admin -e PASSWORD=admin123 perf/k6_order_flow.js
```

#### Load Test (2 minutes, 5 users)
```powershell
k6 run --duration 2m --vus 5 -e USERNAME=admin -e PASSWORD=admin123 perf/k6_order_flow.js
```

### 4. Database Order Lookup Test
```powershell
# Test database-backed order retrieval
python -c @"
import requests
import json

# Login
login_data = {'username': 'admin', 'password': 'admin123'}
login_resp = requests.post('http://localhost:8000/api/v1/auth/login', json=login_data)
token = login_resp.json()['access_token']
headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}

# Create an order with TSLA (likely to trigger buy/sell)
act_data = {'symbol': 'TSLA', 'lookback': 200, 'size_mode': 'fixed', 'fixed_qty': 10.0}
act_resp = requests.post('http://localhost:8000/api/v1/signals/act', json=act_data, headers=headers)

if act_resp.status_code == 200 and act_resp.json()['order']:
    order_id = act_resp.json()['order']['order_id']
    print(f'Created order: {order_id}')
    
    # Test order lookup
    order_resp = requests.get(f'http://localhost:8000/api/v1/orders/{order_id}', headers=headers)
    if order_resp.status_code == 200:
        order_data = order_resp.json()
        print(f'Order lookup successful: {order_data["status"]}')
        print(json.dumps(order_data, indent=2))
    else:
        print(f'Order lookup failed: {order_resp.status_code}')
else:
    print('No order created (likely HOLD action)')
"@
```

## 📊 Expected Test Results

### Successful K6 Test Output
```
✅ signals: status is 2xx
✅ signals: response time < 300ms  
✅ signals: has response body
✅ act: status is 2xx
✅ act: response time < 500ms
✅ act: has response body

checks_succeeded...: 100.00% XXX out of XXX
http_req_failed....: 0.00% 0 out of XXX
```

### Expected Warnings (Normal Behavior)
```
⚠️  Skipping order status check - no valid order ID or act request failed
```
**Note**: These warnings are expected for "hold" actions. The strategy has been temporarily set to AGGRESSIVE mode (RSI: 45/55 instead of 30/70) for testing to generate more orders and reduce warnings.

## 🔍 Troubleshooting

### Server Won't Start
1. **Check Python environment**:
   ```powershell
   python --version  # Should be 3.11+
   pip list | findstr fastapi  # Should show FastAPI installed
   ```

2. **Check port availability**:
   ```powershell
   netstat -an | findstr :8000  # Should be empty if port is free
   ```

3. **Check environment variables**:
   ```powershell
   echo $env:ALPACA_API_KEY_ID  # Should show API key
   ```

### K6 Tests Failing
1. **Verify server is running**:
   ```powershell
   curl http://localhost:8000/
   ```

2. **Check authentication**:
   ```powershell
   curl -X POST "http://localhost:8000/api/v1/auth/login" -H "Content-Type: application/json" -d '{"username": "admin", "password": "admin123"}'
   ```

3. **Test single endpoint**:
   ```powershell
   k6 run --duration 5s --vus 1 -e USERNAME=admin -e PASSWORD=admin123 perf/k6_order_flow.js
   ```

### Database Issues
1. **Check logs**:
   ```powershell
   Get-Content logs/app.log | Select-Object -Last 20
   ```

2. **Reset database** (if needed):
   ```powershell
   # Remove SQLite database to reset
   Remove-Item -Path "*.db" -Force
   ```

### Performance Issues
1. **Reduce test load**:
   ```powershell
   k6 run --duration 10s --vus 1 -e USERNAME=admin -e PASSWORD=admin123 perf/k6_order_flow.js
   ```

2. **Check system resources**:
   ```powershell
   Get-Process python
   ```

### Strategy Configuration
**Current Setting**: AGGRESSIVE mode for testing (RSI: 45/55)
**To revert to conservative**: Edit `backend/api/routes/signals.py` and change RSI thresholds back to:
```python
rsi_buy=30,    # Conservative oversold
rsi_sell=70,   # Conservative overbought
```

## 🎯 Test Validation Checklist

### ✅ Basic Functionality
- [ ] Server starts without errors
- [ ] Health endpoint responds (/)
- [ ] Authentication works (admin/admin123)
- [ ] API documentation loads (/docs)

### ✅ Order Flow (Phase G)
- [ ] Signal generation works (/api/v1/signals/act)
- [ ] Orders created for buy/sell signals
- [ ] Hold actions return properly (no orders)
- [ ] Order lookup works (/api/v1/orders/{id})
- [ ] Database persistence verified

### ✅ Performance & Concurrency  
- [ ] K6 single user test passes (100% success rate)
- [ ] K6 multi-user test passes (100% success rate)
- [ ] No HTTP 500 errors
- [ ] Response times within thresholds
- [ ] No server crashes under load

### ✅ Integration
- [ ] Real Alpaca broker integration (no mocks)
- [ ] Database-backed order storage and retrieval
- [ ] Outbox worker processes events without errors
- [ ] Multiple symbols supported (AAPL, TSLA, NVDA, etc.)

## 📝 Quick Start Command Summary

```powershell
# 1. Setup and Start (run once)
cd "c:\Users\Marsel\intra\algotrading_platform"
.\venv\Scripts\Activate.ps1
$env:ALPACA_API_KEY_ID="PK6HHOLVI6KJ2DTESPKR"; $env:ALPACA_API_SECRET_KEY="vpuCh1GHrr6NBjIecJdc8dGQRa0f302vSmD8kM7W"; $env:ALPACA_PAPER="true"; $env:USE_MOCK_BROKER="false"
python -m uvicorn backend.api.main:app --host 0.0.0.0 --port 8000 --reload

# 2. Run Tests (in separate terminal)
k6 run --duration 30s --vus 2 -e USERNAME=admin -e PASSWORD=admin123 perf/k6_order_flow.js
```

## 🏆 Success Criteria

**Platform is ready for production when:**
- ✅ All K6 tests pass with 100% success rate
- ✅ Zero HTTP failures over sustained load
- ✅ Response times meet thresholds (p95 < 500ms)
- ✅ Order flow works end-to-end (signal → order → lookup)
- ✅ Real broker integration functional
- ✅ Database persistence verified
- ✅ Multi-user concurrent access supported

---

## 📞 Support

If you encounter issues:
1. Check the troubleshooting section above
2. Review server logs: `Get-Content logs/app.log | Select-Object -Last 50`
3. Verify all prerequisites are installed and configured
4. Test with minimal configuration first (single user, short duration)

**Happy Testing! 🚀**