# Day 5 Production Validation Test Suite
# Comprehensive testing and validation for Phase 5 deployment

param(
    [switch]$Fast = $false
)

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "DAY 5: PRODUCTION VALIDATION SUITE" -ForegroundColor Cyan  
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Starting comprehensive Phase 5 validation..." -ForegroundColor Green
Write-Host ""

$startTime = Get-Date
$testResults = @()

# Function to run test and capture results
function Run-TestSuite {
    param($Name, $Command, $Description)
    
    Write-Host "[$((Get-Date).ToString('HH:mm:ss'))] Running: $Name" -ForegroundColor Yellow
    Write-Host "  $Description" -ForegroundColor Gray
    
    $testStart = Get-Date
    try {
        if ($Command -is [string]) {
            Invoke-Expression $Command
        } else {
            & $Command[0] $Command[1..($Command.Length-1)]
        }
        $exitCode = $LASTEXITCODE
        $duration = ((Get-Date) - $testStart).TotalSeconds
        
        if ($exitCode -eq 0) {
            Write-Host "  ✅ PASSED ($([Math]::Round($duration, 2))s)" -ForegroundColor Green
            $script:testResults += @{Name=$Name; Status="PASSED"; Duration=$duration; ExitCode=$exitCode}
        } else {
            Write-Host "  ❌ FAILED (Exit: $exitCode, Duration: $([Math]::Round($duration, 2))s)" -ForegroundColor Red
            $script:testResults += @{Name=$Name; Status="FAILED"; Duration=$duration; ExitCode=$exitCode}
        }
    } catch {
        $duration = ((Get-Date) - $testStart).TotalSeconds
        Write-Host "  ❌ ERROR: $($_.Exception.Message)" -ForegroundColor Red
        $script:testResults += @{Name=$Name; Status="ERROR"; Duration=$duration; ExitCode=-1; Error=$_.Exception.Message}
    }
    Write-Host ""
}

# Test Suite 1: Core Component Validation
Write-Host "Phase 1: Core Component Validation" -ForegroundColor Magenta
Run-TestSuite "Risk Management Validation" "python test_risk_management_validation.py" "Advanced risk manager, portfolio optimizer, dashboard, analytics"

Run-TestSuite "SLO System Validation" "python test_slo_system_validation.py" "SLO monitoring, burn-rate alerts, metrics collection"

Run-TestSuite "Production Components" "python test_production_components.py" "Production-hardened components and guardrails"

# Test Suite 2: Phase G Integration Tests  
Write-Host "Phase 2: Trading Engine Integration" -ForegroundColor Magenta
Run-TestSuite "Phase G Core" "python test_phase_g_core.py" "Core trading engine functionality"

Run-TestSuite "Phase G Integration" "python test_phase_g_integration.py" "End-to-end integration testing"

Run-TestSuite "Phase G Comprehensive" "python test_phase_g_comprehensive.py" "Comprehensive scenario validation"

# Test Suite 3: API and Order Flow
Write-Host "Phase 3: API and Order Flow" -ForegroundColor Magenta  
Run-TestSuite "API Endpoints" "python test_api_endpoints.py" "REST API endpoint validation"

Run-TestSuite "Order Lifecycle" "python -m pytest tests/test_order_lifecycle.py -v" "Complete order processing lifecycle"

Run-TestSuite "Live Order Flow" "python test_live_order_flow.py" "Real-time order flow validation"

# Test Suite 4: Regression and Edge Cases (if not fast mode)
if (-not $Fast) {
    Write-Host "Phase 4: Regression and Edge Cases" -ForegroundColor Magenta
    Run-TestSuite "Regression Fixes" "python test_regression_fixes.py" "Previously identified and fixed issues"
    
    Run-TestSuite "Positions Endpoint" "python test_positions_endpoint.py" "Positions API endpoint validation"
    
    Run-TestSuite "Server Health" "python test_server.py" "Basic server health and startup"
}

# Test Suite 5: Coverage Analysis
Write-Host "Phase 5: Coverage Analysis" -ForegroundColor Magenta
Run-TestSuite "Quick Coverage Check" "python -m pytest -q --cov=backend --cov-branch --cov-report=term-missing:skip-covered --cov-report=html:htmlcov_phase5_final --maxfail=5 --tb=short" "Generate comprehensive coverage report"

# Generate Summary Report
$totalDuration = ((Get-Date) - $startTime).TotalSeconds
$passedTests = ($testResults | Where-Object {$_.Status -eq "PASSED"}).Count
$failedTests = ($testResults | Where-Object {$_.Status -eq "FAILED"}).Count
$errorTests = ($testResults | Where-Object {$_.Status -eq "ERROR"}).Count
$totalTests = $testResults.Count

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "PRODUCTION VALIDATION SUMMARY" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Total Duration: $([Math]::Round($totalDuration, 2)) seconds" -ForegroundColor White
Write-Host "Total Tests: $totalTests" -ForegroundColor White
Write-Host "Passed: $passedTests" -ForegroundColor Green
Write-Host "Failed: $failedTests" -ForegroundColor Red
Write-Host "Errors: $errorTests" -ForegroundColor Red

$successRate = if ($totalTests -gt 0) { [Math]::Round(($passedTests / $totalTests) * 100, 1) } else { 0 }
Write-Host "Success Rate: $successRate%" -ForegroundColor $(if ($successRate -ge 95) {"Green"} elseif ($successRate -ge 80) {"Yellow"} else {"Red"})

Write-Host ""
Write-Host "Detailed Results:" -ForegroundColor White
foreach ($result in $testResults) {
    $statusColor = switch ($result.Status) {
        "PASSED" { "Green" }
        "FAILED" { "Red" }
        "ERROR" { "Magenta" }
    }
    Write-Host "  [$($result.Status)] $($result.Name) - $([Math]::Round($result.Duration, 2))s" -ForegroundColor $statusColor
    if ($result.Error) {
        Write-Host "    Error: $($result.Error)" -ForegroundColor Red
    }
}

Write-Host ""
if ($successRate -ge 95) {
    Write-Host "🎉 PRODUCTION VALIDATION: READY FOR DEPLOYMENT" -ForegroundColor Green
    Write-Host "All critical systems validated successfully!" -ForegroundColor Green
} elseif ($successRate -ge 80) {
    Write-Host "⚠️  PRODUCTION VALIDATION: REVIEW REQUIRED" -ForegroundColor Yellow
    Write-Host "Some tests failed - review before deployment" -ForegroundColor Yellow
} else {
    Write-Host "🚨 PRODUCTION VALIDATION: DEPLOYMENT BLOCKED" -ForegroundColor Red
    Write-Host "Critical failures detected - fix before deployment" -ForegroundColor Red
}

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Coverage report generated: htmlcov_phase5_final/index.html" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan

exit $(if ($successRate -ge 95) {0} else {1})