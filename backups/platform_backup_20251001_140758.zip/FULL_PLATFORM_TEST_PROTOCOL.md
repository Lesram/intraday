# Full Platform Test Protocol

**Version:** 1.0  
**Date:** October 1, 2025  
**Status:** Production Ready ✅

## Overview

This document defines the complete test protocol for validating the entire algorithmic trading platform before production deployment. The protocol consists of 4 phases executed sequentially, with each phase acting as a gate for the next.

---

## 🎯 Test Protocol Summary

| Phase | Test Suite | Duration | Pass Criteria | Purpose |
|-------|-----------|----------|---------------|---------|
| **Phase 1** | Pre-Flight Validation | 2-3 min | 11/11 checks pass | System readiness |
| **Phase 2** | 5-Layer Comprehensive Tests | 30-45 min | 100% pass, >95% coverage | Full functional validation |
| **Phase 3** | Burn-In Stability Test | 135 min | >80% stability score | Long-term stability |
| **Phase 4** | Automated Promotion Gates | 15-20 min | All 6 gates HIGH confidence | Deployment approval |

**Total Duration:** ~3 hours (180-200 minutes)

---

## Phase 1: Pre-Flight Validation ✈️

**Purpose:** Verify system readiness before starting comprehensive tests

**Command:**
```powershell
.\pre_burnin_checklist.ps1
```

**Duration:** 2-3 minutes

### Validation Checks (11 total)

1. ✅ **Python Environment** - Virtual environment activated and functional
2. ✅ **Required Packages** - All dependencies installed (pytest, aiohttp, psutil, etc.)
3. ✅ **K6 Installation** - K6 available for performance testing
4. ✅ **Server Running** - Backend server responding at localhost:8000
5. ✅ **Health Endpoint** - `/health` returns valid status
6. ✅ **Authentication** - JWT token generation working
7. ✅ **SLI Metrics** - `/api/v1/monitoring/sli-metrics` responding
8. ✅ **SLO Status** - `/api/v1/monitoring/slo-status` responding
9. ✅ **Signals Service** - `/api/v1/signals` endpoint available
10. ✅ **Orders Service** - `/api/v1/orders` endpoint available
11. ✅ **Risk Service** - `/api/v1/risk/metrics` endpoint available

### Pass Criteria
- **Required:** 11/11 checks must pass (100%)
- **Output:** Green checkmarks for all items

### On Failure
- Review failed checks in red
- Fix issues before proceeding
- Common issues:
  - Server not running → Start with `.\venv\Scripts\python.exe main.py`
  - Missing packages → Run `pip install -r requirements.txt`
  - K6 not installed → Install from https://k6.io/docs/get-started/installation/

---

## Phase 2: 5-Layer Comprehensive Tests 🏗️

**Purpose:** Complete functional validation of all platform components

**Command:**
```powershell
.\venv\Scripts\python.exe scripts/testing/run_complete_five_layer_tests.py
```

**Duration:** 30-45 minutes

### Test Coverage

#### Layer 1: Database & Models (Foundation)
- ✅ Database connection and configuration
- ✅ Model initialization and relationships
- ✅ CRUD operations for all entities
- ✅ Data integrity and constraints
- ✅ Migration compatibility

#### Layer 2: Authentication & Authorization
- ✅ JWT token generation and validation
- ✅ User registration and login
- ✅ Role-based access control (RBAC)
- ✅ Token refresh and expiration
- ✅ Password hashing and security

#### Layer 3: Core Services
- ✅ Signal generation service
- ✅ Order management service
- ✅ Risk management service
- ✅ Portfolio tracking service
- ✅ Market data integration

#### Layer 4: API & Monitoring
- ✅ REST API endpoints (all routes)
- ✅ Request/response validation
- ✅ Error handling and status codes
- ✅ Monitoring and metrics collection
- ✅ Logging infrastructure

#### Layer 5: Business Workflows (End-to-End)
- ✅ **Complete Trading Workflow**
  - Signal generation → Order creation → Execution → Portfolio update
- ✅ **Risk Management Workflow**
  - Position monitoring → Risk calculation → Guardrail enforcement
- ✅ **User Management Workflow**
  - Registration → Authentication → Authorization → Session management
- ✅ **Market Data Workflow**
  - Data ingestion → Processing → Signal generation → Strategy execution
- ✅ **Paper Trading Workflow**
  - Simulated orders → Virtual portfolio → Performance tracking

### Pass Criteria
- **Required:** 100% test pass rate
- **Coverage:** >95% code coverage (Layers 1-4), 100% workflow coverage (Layer 5)
- **No Critical Errors:** All assertions pass

### Output Review
- Total tests executed
- Pass/fail breakdown by layer
- Code coverage report (html in `test_results/`)
- Any warnings or deprecation notices

### On Failure
- Review pytest output for failed tests
- Check logs in `logs/` directory
- Fix critical issues before proceeding
- Non-critical warnings can be noted for later

---

## Phase 3: Burn-In Stability Test 🔥

**Purpose:** Validate long-term stability under realistic load

**Command:**
```powershell
.\venv\Scripts\python.exe scripts/testing/burn_in_framework.py
```

**Duration:** 135 minutes (~2.25 hours)

### Test Structure

#### 3 Sessions of 45 Minutes Each

**Session 1: Warm-Up (45 min)**
- Initial load testing
- System stabilization
- Baseline metrics collection
- K6 scenarios: 10 VUs, 100 iterations/VU

**Session 2: Sustained Load (45 min)**
- Continuous operation validation
- Memory leak detection
- Performance degradation monitoring
- K6 scenarios: 10 VUs, 100 iterations/VU

**Session 3: Stress Test (45 min)**
- Maximum load validation
- Error recovery testing
- Resource exhaustion scenarios
- K6 scenarios: 10 VUs, 100 iterations/VU

### Monitored Metrics

1. **Authentication Stability**
   - Token generation success rate >99%
   - Token refresh success rate >99%
   - No authentication failures

2. **Performance Metrics**
   - P95 latency <500ms for critical endpoints
   - P99 latency <1000ms for critical endpoints
   - No performance degradation over time

3. **Error Rates**
   - Total error rate <1%
   - No unexpected 500 errors
   - All guardrail violations properly handled

4. **Resource Utilization**
   - Memory usage stable (no leaks)
   - CPU usage within acceptable range
   - Database connections stable

5. **System Health**
   - No crashes or restarts
   - All services remain available
   - Monitoring endpoints responsive

### Pass Criteria
- **Stability Score:** >80% (calculated from all metrics)
- **All 3 Sessions Complete:** No aborts or crashes
- **Authentication Stable:** >99% success rate throughout
- **No Memory Leaks:** Stable memory usage across sessions
- **Error Budget Maintained:** <1% unexpected errors

### Output Review
- Final stability score and trend
- Session-by-session metrics breakdown
- Authentication success rates over time
- Performance percentiles (P50, P95, P99)
- Resource utilization graphs
- Any anomalies or warnings

### On Failure
- Review burn-in logs in `logs/burn_in_*.log`
- Check for memory leaks with memory growth trends
- Investigate authentication failures in server logs
- Review K6 output for error patterns
- May need to fix issues and re-run (another 2.25 hours)

---

## Phase 4: Automated Promotion Gates 🚪

**Purpose:** Final deployment approval decision

**Command:**
```powershell
.\venv\Scripts\python.exe scripts/testing/automated_promotion_gates.py
```

**Duration:** 15-20 minutes

### 6 Promotion Gates

#### Gate 1: System Readiness (CRITICAL)
- ✅ Python environment validated
- ✅ Required packages installed
- ✅ Server health check passed
- ✅ Database connectivity confirmed
- ✅ All services available (signals, orders, risk)

**Confidence Required:** HIGH

#### Gate 2: Unit Test Coverage (CRITICAL)
- ✅ Unit tests pass rate >95%
- ✅ Code coverage >80%
- ✅ No critical test failures
- ✅ All core modules covered

**Confidence Required:** HIGH

#### Gate 3: Integration Testing (CRITICAL)
- ✅ API integration tests pass >90%
- ✅ Service integration validated
- ✅ Database integration tested
- ✅ External service mocks working

**Confidence Required:** HIGH

#### Gate 4: Performance Validation (HIGH)
- ✅ K6 performance tests passed
- ✅ P95 latency <500ms
- ✅ Error rate <1%
- ✅ 100% authentication success
- ✅ Concurrent user handling validated

**Confidence Required:** HIGH

#### Gate 5: SLI/SLO Compliance (MEDIUM)
- ✅ SLI metrics endpoint operational
- ✅ SLO status endpoint operational
- ✅ Error budget >50% remaining
- ✅ Availability >99.5%

**Confidence Required:** MEDIUM

#### Gate 6: Burn-In Stability (HIGH)
- ✅ Burn-in test completed (if run)
- ✅ Stability score >80%
- ✅ Long-term operation validated
- ✅ No memory leaks detected

**Confidence Required:** HIGH (if burn-in was run)

### Pass Criteria
- **All 6 Gates:** Must achieve minimum confidence level
- **No CRITICAL Failures:** All critical gates must pass with HIGH confidence
- **Overall Assessment:** "READY FOR DEPLOYMENT" message

### Output Review
- Gate-by-gate confidence levels
- Detailed metrics for each gate
- Any warnings or recommendations
- Final deployment recommendation

### On Failure
- Review which gate(s) failed
- Check confidence levels (LOW/MEDIUM/HIGH)
- Address root causes
- Re-run promotion gates after fixes

---

## 📋 Complete Test Protocol Execution

### Step-by-Step Instructions

```powershell
# Step 1: Ensure server is running
.\venv\Scripts\python.exe main.py
# Wait for "Application startup complete" message

# Step 2 (in new terminal): Phase 1 - Pre-Flight Validation
.\pre_burnin_checklist.ps1
# Verify: All 11 checks green ✅

# Step 3: Phase 2 - Comprehensive Tests
.\venv\Scripts\python.exe scripts/testing/run_complete_five_layer_tests.py
# Expected: 30-45 minutes, 100% pass rate

# Step 4: Phase 3 - Burn-In Stability Test
.\venv\Scripts\python.exe scripts/testing/burn_in_framework.py
# Expected: 135 minutes, >80% stability score

# Step 5: Phase 4 - Promotion Gates
.\venv\Scripts\python.exe scripts/testing/automated_promotion_gates.py
# Expected: All gates pass with HIGH confidence

# Step 6: Review Results
# Check test_results/ for coverage reports
# Review logs/ for any warnings
# Verify READY FOR DEPLOYMENT message
```

### Total Timeline

| Time | Activity | Status Check |
|------|----------|--------------|
| T+0 | Start server | Server running ✅ |
| T+2 min | Pre-flight validation | 11/11 checks pass ✅ |
| T+5 min | Start 5-layer tests | Tests executing |
| T+45 min | 5-layer tests complete | 100% pass ✅ |
| T+50 min | Start burn-in test | Session 1 begins |
| T+95 min | Burn-in session 1 complete | Session 2 begins |
| T+140 min | Burn-in session 2 complete | Session 3 begins |
| T+185 min | Burn-in complete | >80% stability ✅ |
| T+190 min | Start promotion gates | Gates evaluating |
| T+205 min | **DEPLOYMENT READY** | All gates HIGH ✅ |

**Total Duration:** ~3.5 hours (with server startup and reviews)

---

## 🔍 Alternative Test Protocols

### Quick Validation (Daily Development)

**Purpose:** Rapid feedback during active development  
**Duration:** 15 minutes

```powershell
.\venv\Scripts\python.exe scripts/testing/quick_burn_in_test.py
```

**Coverage:** Core functionality only, reduced load  
**Use When:** Making small changes, need fast feedback

### Pre-Commit Testing (Before Git Commit)

**Purpose:** Validate changes before committing  
**Duration:** 30-45 minutes

```powershell
.\venv\Scripts\python.exe scripts/testing/run_complete_five_layer_tests.py
```

**Coverage:** Full 5-layer test suite  
**Use When:** Before committing significant changes

### Full Platform Suite (Pre-Deployment)

**Purpose:** Complete validation before production  
**Duration:** 3-3.5 hours

**Protocol:** All 4 phases as documented above  
**Use When:** Before deploying to production, after major changes

---

## 📊 Success Metrics

### Phase 1: Pre-Flight ✈️
- ✅ 11/11 checks pass (100%)

### Phase 2: Comprehensive Tests 🏗️
- ✅ 100% test pass rate
- ✅ >95% code coverage
- ✅ All 5 layers validated

### Phase 3: Burn-In 🔥
- ✅ >80% stability score
- ✅ >99% authentication success
- ✅ <1% error rate
- ✅ Stable resource usage

### Phase 4: Promotion Gates 🚪
- ✅ 6/6 gates pass
- ✅ All critical gates HIGH confidence
- ✅ READY FOR DEPLOYMENT message

---

## 🚨 Troubleshooting

### Pre-Flight Fails
- **Server not responding:** Check if `main.py` is running
- **Package missing:** Run `pip install -r requirements.txt`
- **K6 not found:** Install from https://k6.io

### 5-Layer Tests Fail
- **Database errors:** Check database connection in config
- **Import errors:** Verify all modules in `backend/` are accessible
- **Timeout errors:** Increase timeout in pytest.ini

### Burn-In Instability
- **High error rate:** Review K6 test for authentication issues
- **Memory leaks:** Check for unclosed connections or resources
- **Performance degradation:** Profile code for bottlenecks

### Promotion Gates Block
- **Low confidence:** Review individual gate metrics
- **Critical failure:** Address root cause before deployment
- **Inconsistent results:** Re-run affected tests

---

## 📝 Documentation References

- **Testing Architecture:** `scripts/testing/COMPREHENSIVE_TESTING_ARCHITECTURE.md`
- **Cleanup Summary:** `TESTING_CLEANUP_SUMMARY.md`
- **Architecture Analysis:** `TESTING_ARCHITECTURE_ANALYSIS.md`
- **Archive Details:** `archive/legacy_individual_tests/README.md`

---

## ✅ Final Checklist

Before declaring **DEPLOYMENT READY:**

- [ ] Pre-flight validation: 11/11 checks pass
- [ ] 5-layer tests: 100% pass rate, >95% coverage
- [ ] Burn-in test: >80% stability score, all sessions complete
- [ ] Promotion gates: All 6 gates pass with required confidence
- [ ] Documentation: Test results reviewed and logged
- [ ] Logs: No critical errors or warnings
- [ ] Team: Stakeholders notified of deployment readiness

**Date:** ________________  
**Tester:** ________________  
**Deployment Approval:** ________________

---

**Last Updated:** October 1, 2025  
**Maintained By:** Platform Testing Team  
**Questions?** See documentation references above
