# 🚀 **Phase 5 Production Deployment Test Plan**
## **Hedge Fund Grade Trading Platform Validation**

This document provides the comprehensive test plan for Phase 5 deployment, transitioning from mock systems to real Alpaca Paper trading with full production guardrails.

---

## **📊 Pre-Deployment Checklist**

### **✅ Infrastructure Readiness**
- [ ] `.env.paper` configuration validated with real credentials
- [ ] Database migrations applied and tested  
- [ ] WebSocket stream client integrated and tested
- [ ] Alpaca API connectivity confirmed (account, positions, orders)
- [ ] Production guardrails configured and loaded
- [ ] Observability metrics and monitoring setup
- [ ] Backup and rollback procedures documented

### **✅ Code Integration Validation**  
- [ ] Real broker client (`AlpacaBrokerClient`) functional
- [ ] WebSocket stream integration working (`AlpacaStreamClient`)
- [ ] Production guardrails enforced (`TradingGuardrails`)
- [ ] Order flow end-to-end with real broker
- [ ] Database persistence with broker order IDs
- [ ] Error handling and circuit breakers active

---

## **🧪 Test Execution Plan**

### **Phase 1: Environment & Configuration Testing**

#### **Test 1.1: Environment Configuration Validation**
```powershell
# Load paper environment
Set-Location "c:\Users\Marsel\intra\algotrading_platform"
.\venv\Scripts\Activate.ps1

# Set paper environment variables
Get-Content .env.paper | ForEach-Object {
    if ($_ -match "^([^#][^=]+)=(.*)$") {
        [Environment]::SetEnvironmentVariable($matches[1], $matches[2])
    }
}

# Verify environment
python -c @"
import os
print(f"APP_ENV: {os.getenv('APP_ENV')}")
print(f"USE_MOCK_BROKER: {os.getenv('USE_MOCK_BROKER')}")
print(f"ALPACA_PAPER: {os.getenv('ALPACA_PAPER')}")
print(f"SYMBOL_WHITELIST: {os.getenv('SYMBOL_WHITELIST')}")
print(f"DAILY_NOTIONAL_CAP_USD: {os.getenv('DAILY_NOTIONAL_CAP_USD')}")
print(f"TRADING_PAUSED: {os.getenv('TRADING_PAUSED')}")
"@
```

**Expected Results:**
- `APP_ENV=paper`
- `USE_MOCK_BROKER=false`
- `ALPACA_PAPER=true`
- All guardrail settings loaded correctly

#### **Test 1.2: Alpaca Broker Connectivity**
```powershell
# Test Alpaca Paper API connectivity
python -c @"
import asyncio
from backend.integrations.alpaca_broker import AlpacaBrokerClient

async def test_broker():
    client = AlpacaBrokerClient()
    
    # Test account access
    try:
        import httpx
        headers = client._get_auth_headers()
        async with httpx.AsyncClient() as http_client:
            response = await http_client.get(f'{client.base_url}/v2/account', headers=headers)
            if response.status_code == 200:
                account = response.json()
                print(f'✅ Account connected: {account["account_number"]}')
                print(f'✅ Buying power: ${account["buying_power"]}')
                print(f'✅ Paper trading: {client.is_paper}')
                return True
            else:
                print(f'❌ Account access failed: {response.status_code}')
                print(response.text)
                return False
    except Exception as e:
        print(f'❌ Broker connectivity error: {e}')
        return False

result = asyncio.run(test_broker())
print(f'Broker connectivity: {"PASS" if result else "FAIL"}')
"@
```

**Expected Results:**
- Account connection successful
- Positive buying power shown
- Paper trading flag confirmed

---

### **Phase 2: Guardrails & Risk Management Testing**

#### **Test 2.1: Symbol Whitelist Enforcement**
```powershell
# Start server with paper configuration
python -m uvicorn backend.api.main:app --host 0.0.0.0 --port 8000 --reload &

# Wait for startup
Start-Sleep -Seconds 5

# Test guardrail enforcement
python -c @"
import requests
import json

# Login
login_data = {'username': 'admin', 'password': 'admin123'}
login_resp = requests.post('http://localhost:8000/api/v1/auth/login', json=login_data)
token = login_resp.json()['access_token']
headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}

print('🧪 Testing Symbol Whitelist Guardrails')
print('=' * 50)

# Test 1: Allowed symbol (should work)
print('Test 1: Allowed symbol (AAPL)')
try:
    act_data = {'symbol': 'AAPL', 'lookback': 200, 'size_mode': 'fixed', 'fixed_qty': 5.0}
    resp = requests.post('http://localhost:8000/api/v1/signals/act', json=act_data, headers=headers)
    if resp.status_code == 200:
        data = resp.json()
        if data['order']:
            print(f'  ✅ Order created: {data["order"]["order_id"]}')
        else:
            print(f'  ✅ Hold action (expected): {data["action"]}')
    else:
        print(f'  ❌ Unexpected error: {resp.status_code}')
        print(f'     {resp.text}')
except Exception as e:
    print(f'  ❌ Request failed: {e}')

print()

# Test 2: Blocked symbol (should fail)
print('Test 2: Blocked symbol (INVALID)')
try:
    act_data = {'symbol': 'INVALID', 'lookback': 200, 'size_mode': 'fixed', 'fixed_qty': 5.0}
    resp = requests.post('http://localhost:8000/api/v1/signals/act', json=act_data, headers=headers)
    if resp.status_code == 422:
        error_data = resp.json()
        if 'SYMBOL_NOT_ALLOWED' in str(error_data):
            print('  ✅ Symbol correctly blocked by guardrail')
        else:
            print(f'  ❌ Wrong error type: {error_data}')
    else:
        print(f'  ❌ Expected 422 but got: {resp.status_code}')
        print(f'     {resp.text}')
except Exception as e:
    print(f'  ❌ Request failed: {e}')
"@
```

**Expected Results:**
- Whitelisted symbols (AAPL, MSFT, etc.) allowed
- Non-whitelisted symbols blocked with `SYMBOL_NOT_ALLOWED`
- Proper HTTP 422 status codes returned

#### **Test 2.2: Order Size & Daily Limits**
```powershell
# Test order size limits and daily caps
python -c @"
import requests
import json

# Login
login_data = {'username': 'admin', 'password': 'admin123'}
login_resp = requests.post('http://localhost:8000/api/v1/auth/login', json=login_data)
token = login_resp.json()['access_token']
headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}

print('🧪 Testing Order Size & Daily Limit Guardrails')
print('=' * 50)

# Test 1: Large order size (should fail)
print('Test 1: Order size exceeding limit')
try:
    act_data = {'symbol': 'AAPL', 'lookback': 200, 'size_mode': 'fixed', 'fixed_qty': 150.0}  # Exceeds 100 limit
    resp = requests.post('http://localhost:8000/api/v1/signals/act', json=act_data, headers=headers)
    if resp.status_code == 422:
        error_data = resp.json()
        if 'ORDER_SIZE_EXCEEDED' in str(error_data):
            print('  ✅ Large order correctly blocked')
            print(f'     Details: {error_data.get("detail", {}).get("violations", [])}')
        else:
            print(f'  ❌ Wrong error type: {error_data}')
    else:
        print(f'  ❌ Expected 422 but got: {resp.status_code}')
except Exception as e:
    print(f'  ❌ Request failed: {e}')

print()

# Test 2: Check current limits
print('Test 2: Current guardrail status')
try:
    from backend.infra.guardrails import get_guardrails
    guardrails = get_guardrails()
    limits = guardrails.get_current_limits()
    
    print(f'  📊 Daily Orders Used: {limits["daily_limits"]["orders"]["used"]}/{limits["daily_limits"]["orders"]["limit"]}')
    print(f'  📊 Daily Notional Used: ${limits["daily_limits"]["notional_usd"]["used"]}/${limits["daily_limits"]["notional_usd"]["limit"]}')
    print(f'  📊 Trading Window: {limits["trading_window"]["start_utc"]}-{limits["trading_window"]["end_utc"]}')
    print(f'  📊 Trading Paused: {limits["status"]["trading_paused"]}')
    print(f'  📊 Allowed Symbols: {len(limits["symbol_whitelist"])} symbols')
    
except Exception as e:
    print(f'  ❌ Failed to get limits: {e}')
"@
```

**Expected Results:**
- Orders exceeding size limits blocked with `ORDER_SIZE_EXCEEDED`
- Current usage statistics displayed correctly
- Daily limits enforced appropriately

---

### **Phase 3: Real Broker Integration Testing**

#### **Test 3.1: End-to-End Order Flow**
```powershell
# Test complete order flow with real Alpaca Paper
python -c @"
import requests
import json
import time

# Login
login_data = {'username': 'admin', 'password': 'admin123'}
login_resp = requests.post('http://localhost:8000/api/v1/auth/login', json=login_data)
token = login_resp.json()['access_token']
headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}

print('🧪 Testing End-to-End Real Broker Integration')
print('=' * 60)

# Test with symbols likely to generate orders
test_symbols = ['TSLA', 'NVDA', 'GOOGL']
orders_created = []

for symbol in test_symbols:
    print(f'Testing {symbol}:')
    
    try:
        # 1. Submit order via signals endpoint
        act_data = {'symbol': symbol, 'lookback': 200, 'size_mode': 'fixed', 'fixed_qty': 1.0}
        act_resp = requests.post('http://localhost:8000/api/v1/signals/act', json=act_data, headers=headers)
        
        if act_resp.status_code == 200:
            data = act_resp.json()
            
            if data['order']:
                order_id = data['order']['order_id']
                print(f'  ✅ Order created: {order_id}')
                print(f'     Action: {data["action"]} | Reason: {data["signal"]["reason"][:50]}...')
                orders_created.append(order_id)
                
                # 2. Verify order in database immediately
                order_resp = requests.get(f'http://localhost:8000/api/v1/orders/{order_id}', headers=headers)
                if order_resp.status_code == 200:
                    order_data = order_resp.json()
                    print(f'  ✅ Order in database: Status={order_data["status"]}')
                    if order_data.get('broker_order_id'):
                        print(f'     Broker ID: {order_data["broker_order_id"]}')
                else:
                    print(f'  ❌ Order lookup failed: {order_resp.status_code}')
            else:
                print(f'  ✅ Hold action: {data["action"]}')
                print(f'     Reason: {data["signal"]["reason"]}')
        
        elif act_resp.status_code == 422:
            error_data = act_resp.json()
            print(f'  ⚠️  Blocked by guardrails: {error_data.get("detail", {}).get("error", "Unknown")}')
        
        else:
            print(f'  ❌ Unexpected response: {act_resp.status_code}')
            print(f'     {act_resp.text[:200]}')
    
    except Exception as e:
        print(f'  ❌ Error testing {symbol}: {e}')
    
    print()

print(f'📊 Summary: {len(orders_created)} orders created out of {len(test_symbols)} symbols tested')

# 3. Wait and check for order status updates (WebSocket stream should update these)
if orders_created:
    print('⏱️  Waiting 10 seconds for order status updates...')
    time.sleep(10)
    
    print('📈 Checking order status updates:')
    for order_id in orders_created:
        try:
            order_resp = requests.get(f'http://localhost:8000/api/v1/orders/{order_id}', headers=headers)
            if order_resp.status_code == 200:
                order_data = order_resp.json()
                print(f'  Order {order_id}: Status={order_data["status"]}, Filled={order_data.get("filled_qty", 0)}')
            else:
                print(f'  ❌ Failed to get order {order_id}: {order_resp.status_code}')
        except Exception as e:
            print(f'  ❌ Error checking order {order_id}: {e}')
"@
```

**Expected Results:**
- Orders submitted to real Alpaca Paper successfully
- Database immediately updated with order details
- Broker order IDs populated
- WebSocket stream updates order statuses within 10 seconds
- Orders transition from "submitted" → "accepted" → "filled"

#### **Test 3.2: WebSocket Stream Validation**
```powershell
# Test WebSocket streaming separately
python -c @"
import asyncio
import json
from backend.integrations.alpaca_stream import get_stream_client

async def test_websocket_stream():
    print('🧪 Testing Alpaca WebSocket Stream')
    print('=' * 40)
    
    try:
        # Get stream client
        stream_client = get_stream_client()
        
        print('📡 Connecting to Alpaca WebSocket...')
        
        # Test connection
        connected = await stream_client.connect()
        
        if connected:
            print('✅ WebSocket connected and authenticated')
            print('✅ Subscribed to trade_updates stream')
            
            # Listen for a few seconds
            print('👂 Listening for trade updates (10 seconds)...')
            
            # Create a timeout task
            listen_task = asyncio.create_task(stream_client.listen())
            timeout_task = asyncio.create_task(asyncio.sleep(10))
            
            # Wait for either timeout or error
            done, pending = await asyncio.wait(
                [listen_task, timeout_task],
                return_when=asyncio.FIRST_COMPLETED
            )
            
            # Cancel remaining tasks
            for task in pending:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
            
            print('✅ WebSocket stream test completed')
            
            # Disconnect
            await stream_client.stop()
            print('✅ WebSocket disconnected cleanly')
            
        else:
            print('❌ Failed to connect to WebSocket')
            return False
            
        return True
        
    except Exception as e:
        print(f'❌ WebSocket test error: {e}')
        return False

# Run the test
result = asyncio.run(test_websocket_stream())
print(f'WebSocket Stream Test: {"PASS" if result else "FAIL"}')
"@
```

**Expected Results:**
- WebSocket connects to Alpaca successfully
- Authentication completes without errors
- Subscription to trade_updates confirmed
- No connection errors during test period
- Clean disconnection

---

### **Phase 4: Performance & Load Testing**

#### **Test 4.1: Production K6 Load Test**
```powershell
# Run comprehensive K6 test with multiple scenarios
k6 run --duration 60s --vus 3 -e USERNAME=admin -e PASSWORD=admin123 -e TEST_SYMBOL=NVDA perf/k6_order_flow.js
```

**Expected Results:**
- `http_req_failed < 2%` (allowing for occasional broker issues)
- `p(95) < 500ms` for order submissions
- `p(95) < 300ms` for signal generation
- Zero application crashes or server errors
- All orders properly persisted to database

#### **Test 4.2: Concurrent User Testing**
```powershell
# Test multiple concurrent users
k6 run --duration 120s --vus 5 -e USERNAME=admin -e PASSWORD=admin123 perf/k6_order_flow.js
```

**Expected Results:**
- System remains stable under concurrent load
- Order submissions don't interfere with each other
- Database consistency maintained
- Guardrails correctly enforced for all users
- WebSocket stream handles multiple order updates

---

### **Phase 5: Error Handling & Recovery Testing**

#### **Test 5.1: Network Resilience**
```powershell
# Test broker connectivity issues (simulate by temporarily blocking Alpaca IPs)
# This would be done in staging environment with network policies

# Test WebSocket reconnection
python -c @"
import asyncio
from backend.integrations.alpaca_stream import get_stream_client

async def test_reconnection():
    print('🧪 Testing WebSocket Reconnection')
    print('=' * 40)
    
    client = get_stream_client()
    
    # Start with reconnect
    reconnect_task = asyncio.create_task(client.start_with_reconnect())
    
    # Let it run for a bit
    await asyncio.sleep(5)
    
    print('🔌 Simulating connection loss...')
    # Force disconnect
    if client.websocket:
        await client.websocket.close()
    
    # Wait for reconnection
    await asyncio.sleep(15)
    
    # Stop gracefully
    await client.stop()
    
    print('✅ Reconnection test completed')

asyncio.run(test_reconnection())
"@
```

#### **Test 5.2: Database Consistency**
```powershell
# Test order consistency under various failure scenarios
python -c @"
import requests
import json

print('🧪 Testing Database Consistency')
print('=' * 40)

# Login
login_data = {'username': 'admin', 'password': 'admin123'}
login_resp = requests.post('http://localhost:8000/api/v1/auth/login', json=login_data)
token = login_resp.json()['access_token']
headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}

# Submit multiple orders rapidly
order_ids = []
for i in range(5):
    act_data = {'symbol': 'AAPL', 'lookback': 200, 'size_mode': 'fixed', 'fixed_qty': 1.0}
    resp = requests.post('http://localhost:8000/api/v1/signals/act', json=act_data, headers=headers)
    
    if resp.status_code == 200:
        data = resp.json()
        if data['order']:
            order_ids.append(data['order']['order_id'])

print(f'Created {len(order_ids)} orders for consistency check')

# Verify all orders exist and have proper data
consistent = True
for order_id in order_ids:
    resp = requests.get(f'http://localhost:8000/api/v1/orders/{order_id}', headers=headers)
    if resp.status_code != 200:
        print(f'❌ Order {order_id} not found')
        consistent = False
    else:
        order_data = resp.json()
        if not all(k in order_data for k in ['symbol', 'side', 'qty', 'status']):
            print(f'❌ Order {order_id} missing required fields')
            consistent = False

print(f'Database consistency: {"✅ PASS" if consistent else "❌ FAIL"}')
"@
```

---

### **Phase 6: Production Readiness Validation**

#### **Test 6.1: Monitoring & Observability**
```powershell
# Check metrics endpoint
curl http://localhost:8000/metrics

# Verify key metrics are present
python -c @"
import requests

try:
    resp = requests.get('http://localhost:8000/metrics')
    metrics_text = resp.text
    
    required_metrics = [
        'orders_submitted_total',
        'orders_filled_total', 
        'http_requests_total',
        'process_cpu_seconds_total'
    ]
    
    print('🧪 Testing Observability Metrics')
    print('=' * 40)
    
    for metric in required_metrics:
        if metric in metrics_text:
            print(f'✅ {metric} - Present')
        else:
            print(f'❌ {metric} - Missing')
            
except Exception as e:
    print(f'❌ Metrics endpoint error: {e}')
"@
```

#### **Test 6.2: Health Checks**
```powershell
# Test health endpoint
curl http://localhost:8000/health

# Detailed health check
python -c @"
import requests
import json

try:
    resp = requests.get('http://localhost:8000/health')
    health_data = resp.json()
    
    print('🧪 Testing Health Checks')
    print('=' * 30)
    print(json.dumps(health_data, indent=2))
    
    # Check critical components
    if health_data.get('status') == 'healthy':
        print('✅ Overall health: HEALTHY')
    else:
        print(f'❌ Overall health: {health_data.get("status", "UNKNOWN")}')
        
except Exception as e:
    print(f'❌ Health check error: {e}')
"@
```

---

## **📋 Test Results Documentation**

### **Test Execution Log Template**

```markdown
# Phase 5 Test Execution Results
Date: [YYYY-MM-DD]
Tester: [Name]
Environment: Paper Trading
Commit Hash: [git hash]

## Test Results Summary
- Environment Setup: ✅/❌
- Broker Integration: ✅/❌  
- Guardrails: ✅/❌
- WebSocket Streaming: ✅/❌
- Performance: ✅/❌
- Error Handling: ✅/❌
- Observability: ✅/❌

## Detailed Results
[Include screenshots, logs, and detailed test outputs]

## Issues Identified
1. [Issue description]
   - Severity: Critical/High/Medium/Low
   - Status: Open/Fixed
   - Action: [Next steps]

## Performance Metrics
- Order submission p95: [X]ms
- Signal generation p95: [X]ms  
- HTTP error rate: [X]%
- WebSocket reconnections: [X] during test

## Recommendation
✅ APPROVED for production deployment
❌ REQUIRES fixes before deployment
⚠️  APPROVED with monitoring
```

---

## **🚀 Production Deployment Go/No-Go Criteria**

### **✅ Required for GO Decision**
1. **All critical path tests pass** (Phases 1-3)
2. **Performance meets thresholds** (Phase 4)
3. **Error recovery validated** (Phase 5) 
4. **Monitoring operational** (Phase 6)
5. **Zero critical or high severity issues**
6. **Rollback procedure validated**

### **❌ No-Go Triggers**
1. Broker integration failures
2. Data consistency issues
3. Performance below thresholds
4. Guardrail bypasses possible
5. WebSocket stream instability
6. Critical monitoring gaps

### **⚠️ Conditional Go (With Enhanced Monitoring)**
1. Minor performance degradation
2. Non-critical feature issues
3. Monitoring alerts tuning needed
4. Documentation gaps

---

## **📞 Escalation Procedures**

### **During Testing**
- **Critical Issues**: Immediate escalation, halt testing
- **Performance Issues**: Complete current phase, escalate
- **Minor Issues**: Document, continue testing

### **Post-Deployment** 
- **24/7 Monitoring**: First 48 hours
- **Daily Reviews**: First week
- **Weekly Reviews**: First month
- **Alert Thresholds**: Conservative initially

---

**This comprehensive test plan ensures hedge fund grade reliability and performance for the Phase 5 production deployment.** 🎯