# Phase G Comprehensive Test Runner
# Runs all tests to validate Phase G implementation

param(
    [switch]$SkipK6 = $false,
    [switch]$QuickTest = $false,
    [string]$ServerUrl = "http://localhost:8000"
)

Write-Host "🚀 Phase G Comprehensive Test Suite" -ForegroundColor Green
Write-Host "=" * 50

# Check if server is running
Write-Host "🔍 Checking if server is running..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$ServerUrl/health" -Method GET -TimeoutSec 5
    Write-Host "✅ Server is running and healthy" -ForegroundColor Green
}
catch {
    Write-Host "❌ Server is not running or not responding" -ForegroundColor Red
    Write-Host "Please start the server first:" -ForegroundColor Yellow
    Write-Host "  python -m uvicorn backend.api.main:app --host 0.0.0.0 --port 8000 --reload" -ForegroundColor Cyan
    exit 1
}

# Set environment variables
$env:ALPACA_API_KEY_ID = "PK6HHOLVI6KJ2DTESPKR"
$env:ALPACA_API_SECRET_KEY = "vpuCh1GHrr6NBjIecJdc8dGQRa0f302vSmD8kM7W"
$env:ALPACA_PAPER = "true"
$env:USE_MOCK_BROKER = "false"
$env:SECURITY_JWT_SECRET = "your-super-secret-jwt-key-min-32-chars-long-12345"

$testResults = @{}
$totalTests = 0
$passedTests = 0

function Run-Test {
    param(
        [string]$TestName,
        [scriptblock]$TestCommand
    )
    
    Write-Host "`n🧪 Running $TestName..." -ForegroundColor Cyan
    $global:totalTests++
    
    try {
        $result = & $TestCommand
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✅ $TestName: PASSED" -ForegroundColor Green
            $global:testResults[$TestName] = $true
            $global:passedTests++
        }
        else {
            Write-Host "❌ $TestName: FAILED (Exit Code: $LASTEXITCODE)" -ForegroundColor Red
            $global:testResults[$TestName] = $false
        }
    }
    catch {
        Write-Host "❌ $TestName: ERROR - $($_.Exception.Message)" -ForegroundColor Red
        $global:testResults[$TestName] = $false
    }
}

# Test 1: Core Database Tests
Run-Test "Core Database Tests" {
    python test_phase_g_core.py
}

# Test 2: Authentication Test
Run-Test "Authentication Test" {
    $loginData = @{
        username = "admin"
        password = "admin123"
    } | ConvertTo-Json
    
    try {
        $response = Invoke-RestMethod -Uri "$ServerUrl/auth/login" -Method POST -Body $loginData -ContentType "application/json"
        if ($response.access_token) {
            Write-Host "  ✅ JWT token received" -ForegroundColor Green
            $true
        } else {
            $false
        }
    }
    catch {
        Write-Host "  ❌ Authentication failed: $($_.Exception.Message)" -ForegroundColor Red
        $false
    }
}

# Test 3: Health Check Performance
Run-Test "Health Check Performance" {
    $startTime = Get-Date
    try {
        $response = Invoke-RestMethod -Uri "$ServerUrl/health" -Method GET
        $duration = (Get-Date) - $startTime
        $durationMs = $duration.TotalMilliseconds
        
        if ($durationMs -lt 100) {
            Write-Host "  ✅ Health check: ${durationMs}ms (under 100ms threshold)" -ForegroundColor Green
            $true
        } else {
            Write-Host "  ❌ Health check: ${durationMs}ms (over 100ms threshold)" -ForegroundColor Red
            $false
        }
    }
    catch {
        Write-Host "  ❌ Health check failed: $($_.Exception.Message)" -ForegroundColor Red
        $false
    }
}

# Test 4: Positions Endpoint
Run-Test "Positions Endpoint" {
    try {
        # Get token first
        $loginData = @{
            username = "admin"
            password = "admin123"
        } | ConvertTo-Json
        
        $loginResponse = Invoke-RestMethod -Uri "$ServerUrl/auth/login" -Method POST -Body $loginData -ContentType "application/json"
        $token = $loginResponse.access_token
        $headers = @{ Authorization = "Bearer $token" }
        
        $response = Invoke-RestMethod -Uri "$ServerUrl/positions" -Method GET -Headers $headers
        Write-Host "  ✅ Positions endpoint accessible" -ForegroundColor Green
        $true
    }
    catch {
        Write-Host "  ❌ Positions endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
        $false
    }
}

# Test 5: Single Order Flow Test
Run-Test "Single Order Flow" {
    try {
        # Get token
        $loginData = @{
            username = "admin"
            password = "admin123"
        } | ConvertTo-Json
        
        $loginResponse = Invoke-RestMethod -Uri "$ServerUrl/auth/login" -Method POST -Body $loginData -ContentType "application/json"
        $token = $loginResponse.access_token
        $headers = @{ Authorization = "Bearer $token" }
        
        # Submit signal
        $signalData = @{
            symbol = "AAPL"
            signal_strength = 0.8
            timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
            features = @{ test = $true }
            metadata = @{ source = "powershell_test" }
        } | ConvertTo-Json
        
        $signalResponse = Invoke-RestMethod -Uri "$ServerUrl/signals/act" -Method POST -Body $signalData -ContentType "application/json" -Headers $headers
        
        if ($signalResponse.order -and $signalResponse.order.order_id) {
            $orderId = $signalResponse.order.order_id
            Write-Host "  ✅ Order created: $orderId" -ForegroundColor Green
            
            # Test status lookup
            $statusResponse = Invoke-RestMethod -Uri "$ServerUrl/orders/$orderId" -Method GET -Headers $headers
            Write-Host "  ✅ Order status retrieved successfully" -ForegroundColor Green
            $true
        } else {
            Write-Host "  ❌ No order ID in response" -ForegroundColor Red
            $false
        }
    }
    catch {
        Write-Host "  ❌ Order flow test failed: $($_.Exception.Message)" -ForegroundColor Red
        $false
    }
}

# Test 6: K6 Performance Test (unless skipped)
if (-not $SkipK6 -and -not $QuickTest) {
    Run-Test "K6 Performance Test" {
        if (Get-Command k6 -ErrorAction SilentlyContinue) {
            Write-Host "  🏃 Running K6 load test..." -ForegroundColor Yellow
            
            $duration = if ($QuickTest) { "10s" } else { "30s" }
            $vus = if ($QuickTest) { 2 } else { 5 }
            
            $k6Result = & k6 run --duration=$duration --vus=$vus -e USERNAME=admin -e PASSWORD=admin123 perf/k6_order_flow.js
            
            if ($LASTEXITCODE -eq 0) {
                Write-Host "  ✅ K6 performance test completed successfully" -ForegroundColor Green
                $true
            } else {
                Write-Host "  ❌ K6 performance test failed" -ForegroundColor Red
                $false
            }
        } else {
            Write-Host "  ⚠️  K6 not installed, skipping performance test" -ForegroundColor Yellow
            Write-Host "  Install K6: https://k6.io/docs/getting-started/installation/" -ForegroundColor Cyan
            $true  # Don't fail the whole suite for missing K6
        }
    }
} else {
    Write-Host "`n⏭️  Skipping K6 test (use -SkipK6:$false to include)" -ForegroundColor Yellow
}

# Test 7: Comprehensive Test Suite (if not quick test)
if (-not $QuickTest) {
    Run-Test "Comprehensive Test Suite" {
        python test_phase_g_comprehensive.py
    }
}

# Print Summary
Write-Host "`n" + "="*50 -ForegroundColor Cyan
Write-Host "📊 PHASE G TEST RESULTS SUMMARY" -ForegroundColor Green
Write-Host "="*50 -ForegroundColor Cyan

foreach ($test in $testResults.GetEnumerator()) {
    $status = if ($test.Value) { "✅ PASS" } else { "❌ FAIL" }
    $color = if ($test.Value) { "Green" } else { "Red" }
    Write-Host "$status $($test.Key)" -ForegroundColor $color
}

$successRate = if ($totalTests -gt 0) { [math]::Round(($passedTests / $totalTests) * 100, 1) } else { 0 }
Write-Host "`n📈 Overall Results: $passedTests/$totalTests tests passed ($successRate%)" -ForegroundColor Cyan

if ($passedTests -eq $totalTests -and $totalTests -gt 0) {
    Write-Host "`n🎉 ALL PHASE G TESTS PASSED! 🚀" -ForegroundColor Green
    Write-Host "Phase G implementation is working correctly!" -ForegroundColor Green
    exit 0
} else {
    Write-Host "`n⚠️  Some tests failed. Please review and fix issues." -ForegroundColor Yellow
    Write-Host "Check server logs and test output for details." -ForegroundColor Yellow
    exit 1
}